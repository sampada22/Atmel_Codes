/*
 * debug_encoder.cpp
 *
 * Created: 12/10/2017 1:59:29 AM
 * Author : Sampada Dhakal
 */ 
#define  F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include "lcd.h"


volatile long signed count = 0;
int a = 0;

int main(void)
{   
	DDRD = (0<<PIND2);
	PORTD = (0<<PIND2);
	
	lcd_init();           
	MCUCR = (1<<ISC01)| (1<<ISC00);
	GICR  = (1<<INT0);
	sei();
    while(2)
	{
	  lcd_gotoxy(1,2);
	  lcd_putint(count);
    }
}
ISR (INT0_vect){
	
	count++;
}

