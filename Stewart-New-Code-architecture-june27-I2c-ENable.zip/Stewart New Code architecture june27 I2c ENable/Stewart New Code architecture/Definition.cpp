/*
 * Definition.cpp
 *
 * Created: 5/25/2017 10:35:59 AM
 *  Author: Bibek Shrestha
 */ 


 #include "Declaration.h"




 void Initialise()
 {
	i2c_init();
	uart0_init(UART_BAUD_SELECT(38400,   F_CPU));
	uart3_init(UART_BAUD_SELECT(38400,   F_CPU));
	uart0_puts("Back in black, I hit the sack.");
	DDRK = 0x80;
	
 }