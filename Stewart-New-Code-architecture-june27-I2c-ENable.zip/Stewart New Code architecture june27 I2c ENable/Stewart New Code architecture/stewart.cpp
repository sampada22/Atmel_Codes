/*
 * Stewart New Code architecture.cpp
 *
 * Created: 5/24/2017 10:07:10 PM
 * Author : Bibek Shrestha
 */ 


 #ifndef F_CPU 
 #define F_CPU 16000000UL
 #endif


 #define PRE_MOTOR1_PIN D,7
 #define PRE_MOTOR2_PIN L,7
 #define PRE_MOTOR3_PIN G,1



//#include "headers.h"
#include "Declaration.h"
#include "Leg1.h"
#include "Leg2.h"
#include "Leg3.h"
#include "LengthCalculator.h"
#include "headers.h"


LengthCalculator Calculator;
Leg1 Leg11;
Leg2 Leg22;
Leg3 Leg33;

unsigned char rx;
unsigned char Rx_Buffer = 0;
bool CalculatorReturn = false;


int main(void)
{

	PULLUP_ON(PRE_MOTOR1_PIN);
	PULLUP_ON(PRE_MOTOR2_PIN);
	PULLUP_ON(PRE_MOTOR3_PIN);

	
	sei();

	if(1)
	{	
		Motor1 PreMotor1;
		Motor2 PreMotor2;
		Motor3 PreMotor3;

		PreMotor1.Initialise();
		PreMotor2.Initialise();
		PreMotor3.Initialise();
		


		PreMotor1.SetOcrValue(30);
		PreMotor1.SetForwardDirection();

		PreMotor2.SetOcrValue(30);
		PreMotor2.SetForwardDirection();

		PreMotor3.SetOcrValue(30);
		PreMotor3.SetForwardDirection();

		_delay_ms(800);
		PreMotor1.SetReverseDirection();
		PreMotor2.SetReverseDirection();
		PreMotor3.SetReverseDirection();
		
		char C1 = 0, C2 = 0, C3 = 0;

		while(true)
		{
			if(!(READ(PRE_MOTOR1_PIN)))
			{
				C1++;
				if(C1 > 10)
					PreMotor1.StopMotor();
			}
			if(!(READ(PRE_MOTOR2_PIN)))
			{
				C2++;
				if(C2 > 10)
					PreMotor2.StopMotor();
			}
			if(!(READ(PRE_MOTOR3_PIN)))
			{
				C3++;
				if(C3 > 10)
					PreMotor3.StopMotor();
			}

			if(! (READ(PRE_MOTOR1_PIN) | READ(PRE_MOTOR2_PIN) | READ(PRE_MOTOR3_PIN)))
			{
				PreMotor1.StopMotor();
				PreMotor2.StopMotor();
				PreMotor3.StopMotor();
				break;
			}
				
			
		}

	}	
	cli();

	Initialise();

	Calculator.Initialise();
	Leg11.Initialise(Calculator.length[0]);
	Leg22.Initialise(Calculator.length[1]);
	Leg33.Initialise(Calculator.length[2]);
	

	sei();
  
    while (1) 
    {
		
		Rx_Buffer = COMPIN;
			
		if(STATUS_DE_STROBE(Rx_Buffer))
		{
			

			if(!(STATUS_DE_ACKNOWLEDGE(Rx_Buffer)))
			{
				COMPORT |=  ( 1 << ACKNOWLEDGE);
			
				Rx_Buffer = 0;
			}
			else
				Rx_Buffer = 0;
		}
		else
		{
			if(STATUS_DE_ACKNOWLEDGE(Rx_Buffer))
			{
				COMPORT &= ~(1 << ACKNOWLEDGE);
				
				Rx_Buffer = COMPIN;
				if( Rx_Buffer != 0x00)
				{
					uart0_putint(Rx_Buffer);
				}
				uart0_puts("Got it\n\r");
			}
			else
				Rx_Buffer = 0;
		}
		
	
		

		if(uart0_available())
		{
			rx = uart0_getc();
		
			switch(rx)
			{
				case '.':
				Leg11.Motor.StopMotor();
				Leg22.Motor.StopMotor();
				Leg33.Motor.StopMotor();
				uart0_puts("FINE!!! I will stop. :)");
				while(1)
				{
					
					if(uart0_available())
					rx = uart0_getc();
					if(rx == '+')
					break;
				}
				break;
				case '1':
				Calculator.length[0] += 5;
				uart0_putint(Calculator.length[0]);uart0_putc(' ');
				CalculatorReturn = true;
				break;


				case '2':
				Calculator.length[1] += 5;
				uart0_putint(Calculator.length[1]);uart0_putc(' ');
				CalculatorReturn = true;
				break;

				case '3':
				Calculator.length[2] += 5;
				CalculatorReturn = true;
				uart0_putint(Calculator.length[2]);uart0_putc(' ');
				break;


				case '4':
				Calculator.length[0] -= 5;
				uart0_putint(Calculator.length[0]);uart0_putc(' ');
				CalculatorReturn = true;
				break;

				case '5':
				Calculator.length[1] -= 5;
				uart0_putint(Calculator.length[1]);uart0_putc(' ');
				CalculatorReturn = true;
				break;

				case '6':
				Calculator.length[2] -= 5;
				uart0_putint(Calculator.length[2]);uart0_putc(' ');
				CalculatorReturn = true;
				break;

				case 'q':
				uart0_putint(Calculator.roll*100);uart0_putc(' ');
				uart0_putint(Calculator.pitch*100);uart0_putc(' ');
				break;

			}

			if(CalculatorReturn)
			{

				Leg11.Operate( (Calculator.length + 0) ,true);
				Leg22.Operate( (Calculator.length + 1) ,true);
				Leg33.Operate( (Calculator.length + 2) ,true);

			}

		}





		if( Calculator.Operate(Rx_Buffer ) )
		{
			Leg11.Operate( (Calculator.length + 0) ,true);
			Leg22.Operate( (Calculator.length + 1) ,true);
			Leg33.Operate( (Calculator.length + 2) ,true);

		}
		else
		{
			Leg11.Operate( (Calculator.length + 0) ,false);
			Leg22.Operate( (Calculator.length + 1) ,false);
			Leg33.Operate( (Calculator.length + 2) ,false);

		}
		


		CalculatorReturn = false;
		Rx_Buffer = 0;
		rx  = 0;
    }
}








ISR(INT_ENCODER1A_VECT)
{
	
	if(READ(ENCODER1B))
	{
		Leg11.Encoder.UpFlag = true;
		++Leg11.Encoder.Count;
	}
	else
	{
		Leg11.Encoder.UpFlag = false;
		--Leg11.Encoder.Count;
	}
		
	
		

}



ISR(INT_ENCODER2A_VECT)
{
	//uart0_puts("B\n\r");
	if(!READ(ENCODER2B))
	{
		Leg22.Encoder.UpFlag = true;
		++Leg22.Encoder.Count;
	}
	else
	{
		Leg22.Encoder.UpFlag = false;
		--Leg22.Encoder.Count;
	}

}


ISR(INT_ENCODER3A_VECT)

{
	//uart0_puts("C\n\r");
	if(READ(ENCODER3B))
	{
		Leg33.Encoder.UpFlag = true;
		++Leg33.Encoder.Count;
	}
	else
	{
		Leg33.Encoder.UpFlag = false;
		--Leg33.Encoder.Count;
	}

}