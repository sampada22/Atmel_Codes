/* 
* Leg1.cpp
*
* Created: 5/24/5017 10:23:29 PM
* Author: Bibek Shrestha
*/


#include "Leg1.h"

#define BAND 30

void Leg1::Initialise(float HomeLength_)
{
	
	HomeLength		= HomeLength_;
	TargetCount		= 0;
	Encoder.Initialise();
	Motor.Initialise();

}




bool Leg1::Operate(float * Length, bool ChangeFlag)
{

	static bool UpFlag;

	if(ChangeFlag)
	{
		TargetCount = MM_2_COUNT( *Length - HomeLength);
		
	}

	UpFlag =  (TargetCount >= Encoder.Count);

	
	if(abs(TargetCount - Encoder.Count) < BAND)
	{
		Motor.StopMotor();
		UpFlag = true;
		return true;
	}
	


	if(UpFlag)
	{
		Motor.SetForwardDirection();
		Motor.SetOcrValue(50);

	}
	else
	{
		Motor.SetReverseDirection();
		Motor.SetOcrValue(50);

	}
	

	uart0_puts("A:");
	uart0_putint(TargetCount);
	uart0_putc(' ');
	uart0_putint(Encoder.Count);
	uart0_puts("   ");

	

	return false;

}


