/*
 * Declaration.h
 *
 * Created: 5/25/2017 10:35:40 AM
 *  Author: Bibek Shrestha
 */ 


#ifndef DECLARATION_H_
#define DECLARATION_H_



#include "headers.h"



void Initialise();




#endif /* DECLARATION_H_ */