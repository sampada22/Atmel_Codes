/* 
* Leg3.cpp
*
* Created: 5/25/2017 10:06:08 AM
* Author: Bibek Shrestha
*/


#include "Leg3.h"

#define BAND 30


void Leg3::Initialise(float HomeLength_)
{
	
	HomeLength		= HomeLength_;
	TargetCount		= 0;
	Encoder.Initialise();
	Motor.Initialise();

}



bool Leg3::Operate(float * Length, bool ChangeFlag)
{

	static bool UpFlag;

	if(ChangeFlag)
	{
		TargetCount = MM_2_COUNT( *Length - HomeLength)  ;
		
	}

	UpFlag =  (TargetCount >= Encoder.Count);

	if(abs(TargetCount - Encoder.Count) < BAND)
	{
		Motor.StopMotor();
		UpFlag = true;
		return true;
	}

	if(UpFlag)
	{
		Motor.SetForwardDirection();
		Motor.SetOcrValue(50);

	}
	else
	{
		Motor.SetReverseDirection();
		Motor.SetOcrValue(50);

	}
	

	uart0_puts("C:");
	uart0_putint(TargetCount);
	uart0_putc(' ');
	uart0_putint(Encoder.Count);

	
	
	
	return false;

}


